<?php
// specific ipfs delete actions when deleting attachement
// add_action('delete_attachment', function ($attachmentId) {
// unpin IPFS ?
// });
