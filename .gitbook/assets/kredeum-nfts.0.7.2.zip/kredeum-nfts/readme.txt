=== Kredeum NFTs, The easiest way to sell your content to NFTs Marketplaces ===
Contributors: yoannr35, alexr35, alain
Donate link:  https://www.kredeum.com/
Tags: nft, blockchain, ethereum, ipfs
Requires at least: 5.0
Tested up to: 5.7.2
Stable tag: 0.7.2
Requires PHP: 7.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Convert, archive & sell your content (media, texts, …) to NFTs Marketplaces in an easy and fast way.

== Description ==

The Wordpress Kredeum NTFs plugin allows you to:
* Store all your medias in IPFS (decentralised storage technology), protecting your medias to be lost in case of any hosting server issues. You’ll need to create a NFT Storage (https://nft.storage/) account to manage your IPFS cloud access.
* Create your NFTs uses [Polygon / Matic blockchain](https://matic.network/) (Ethereum layer 2 network) for a transaction cheap cost, Ethereum or BSC (Binance Smart Chain)
* Add in one click your Kredeum NFTs to the OpenSea NFT marketplace [OpenSea](https://opensea.io/)
* Sell your media NFTs on NFTs marketplaces

Please don’t hesitate to contact us if you have any questions by email contact@kredeum.com or by joining us on Discord https://discord.gg/D7Zy4VBzYz

== Useful links / docs ==

* [Read Kredeum NFTs documentation, installation and user guide](https://docs.kredeum.tech/)
* [Watch Kredeum NFTs presentation on Youtube](https://www.youtube.com/watch?v=PWYbeLTXTKE)

== Pre-requirements ==

1. Need to install Metamask extension on your chrome browser + create Metamask account: https://metamask.io/download.html
2. Buy Polygon / Matic, BSC or Ethereum on token exchange platforms like Binance, Bittrex, Coinbase, Ledger Live, … and transfer your new tokens to your Metamask account
3. Create your [NFT Storage](https://nft.storage/) account and get needed keys requested in Kredeum NFTs Settings admin page /wp-admin/admin.php?page=ipfs_settings

== How can you sell one of your wordpress medias? ==

1. In list of medias, Click on MINT NFT to create your NFT
2. Click on SELL NFT to access your list of Kredeum NFTs
3. In list of Kredeum NFTs, click on Opensea to see your NFTs on theis marketplace.

== Changelog ==

= 0.7.2 =
* Easy access to other networks with Metamask: links at the bottom of NFTs page

= 0.7.1 =
* Access all your NFTs on the blockchain you are connected to, in "NFTs" page
* One NFT collection is defined per blockchain to Mint your NFT, but now a new listbox allows you to access your NFTs in other ERC721 collections (if you have some !) 
* In addition to existing Matic/Polygon network (and Mumbai/Polygon tesnet), these blockchains are now supported :
1 Ethereum mainnet
1 Fantom
1 Binance Smart Chain (BSC) 
1 Kovan testnet

= 0.5.2 =
* Fix bug : image links display in posts

= 0.5.1 =
* Loading and Display improved times

= 0.5.0 =
* Settings simplification : only NFT Storage settings needed

= 0.4.9 =
* Bug fixes
* Performance improvements thanks to [Kredeum NFTs subgraph](https://thegraph.com/explorer/subgraph/zapaz/kredeum-nft)

= 0.4.8 =
* Readme updates

= 0.4.7 =
* Initial plugin release
